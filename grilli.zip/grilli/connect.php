<?php
// Get form data
$name = $_POST["name"] ?? '';
$phone = $_POST["phone"] ?? '';
$person_outline = $_POST["person_outline"] ?? '';
$date = $_POST["date"] ?? '';
$time_outline = $_POST["time_outline"] ?? '';
$message = $_POST["message"] ?? '';

// Validate and sanitize inputs
$name = htmlspecialchars(trim($name));
$phone = filter_var($phone, FILTER_SANITIZE_NUMBER_INT);
$person_outline = filter_var($person_outline, FILTER_SANITIZE_NUMBER_INT);
$date = htmlspecialchars(trim($date));
$time_outline = htmlspecialchars(trim($time_outline));
$message = htmlspecialchars(trim($message));

// Validate date and time formats
if (!preg_match("/^\d{4}-\d{2}-\d{2}$/", $date) || !preg_match("/^\d{2}:\d{2}:\d{2}$/", $time_outline)) {
    die("Invalid date or time format. Please use YYYY-MM-DD for date and HH:MM:SS for time.");
}

// Database connection
$conn = new mysqli('localhost', 'root', '', 'bookingxyz');

// Check connection
if ($conn->connect_error) {
    die('Connection Failed: Please try again later.');
}

// Prepare and bind SQL statement
$stmt = $conn->prepare("INSERT INTO tablexyz (name, phone, person, date, time, message) VALUES (?, ?, ?, ?, ?, ?)");
if ($stmt) {
    $stmt->bind_param("siisss", $name, $phone, $person_outline, $date, $time_outline, $message);
    
    // Execute the statement
    if ($stmt->execute()) {
        echo "You have successfully booked a table!";
    } else {
        error_log("SQL Error: " . $stmt->error);
        echo "Something went wrong. Please try again.";
    }
    $stmt->close();
} else {
    error_log("SQL Preparation Error: " . $conn->error);
    echo "We encountered a problem. Please try again later.";
}

// Close the connection
$conn->close();
?>
